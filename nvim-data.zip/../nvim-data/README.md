# nvim-data
nvim-plugins I'm usnig
