local SignsConfig = require('gitsigns.config').Config.SignsConfig

local M = {Sign = {}, HlDef = {}, }



























   -- Used by signs/extmarks.tl


   -- Used by signs/vimfn.tl











return M
